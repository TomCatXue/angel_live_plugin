const BASE_URL = "https://missav.live"

async function request(url) {
    const res = await fetch(url, {
        headers: {
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "referer": BASE_URL
        }
    })
    return await res.text()
}

// 提取页面的公共视频解析逻辑
function parseVideoList(html) {
    const reg = /href="([^"]+)"[^>]*>\s*<img[^>]*src="([^"]+)"[^>]*alt="([^"]+)"/g
    const list = []
    for (const item of html.matchAll(reg)) {
        if (item[1].includes("/search/") || item[1].includes("/genres/")) continue;
        list.push({
            roomId: item[1],
            title: item[3],
            cover: item[2]
        })
    }
    return list
}

globalThis.plugin = {
    // 修复关键：按照官方规范返回 apiVersion 结构
    async categories() {
        return {
            apiVersion: 1,
            categories: [
                { id: "new", name: "最新发布" },
                { id: "chinese-subtitle", name: "中文字幕" },
                { id: "censored", name: "观看日本 AV" },
                { id: "amateur", name: "素人" },
                { id: "uncensored", name: "无码影片" },
                { id: "individual", name: "亚洲 AV" }
            ]
        }
    },

    // 同样为列表返回规范化结构
    async rooms(categoryId, page) {
        let url = BASE_URL
        const pageSuffix = page > 1 ? `?page=${page}` : ""

        if (categoryId === "new") {
            url = `${BASE_URL}/new${pageSuffix}`
        } else if (categoryId === "chinese-subtitle") {
            url = `${BASE_URL}/chinese-subtitle${pageSuffix}`
        } else if (categoryId === "censored") {
            url = `${BASE_URL}/censored${pageSuffix}`
        } else if (categoryId === "amateur") {
            url = `${BASE_URL}/amateur${pageSuffix}`
        } else if (categoryId === "uncensored") {
            url = `${BASE_URL}/uncensored${pageSuffix}`
        } else if (categoryId === "individual") {
            url = `${BASE_URL}/individual${pageSuffix}`
        }

        try {
            const html = await request(url)
            const roomsList = parseVideoList(html)
            return {
                apiVersion: 1,
                rooms: roomsList
            }
        } catch (e) {
            return {
                apiVersion: 1,
                rooms: []
            }
        }
    },

    // 搜索功能
    async search(keyword) {
        const html = await request(
            `${BASE_URL}/search/${encodeURIComponent(keyword)}`
        )
        return parseVideoList(html)
    },

    // 播放地址解析
    async getPlayback(roomId) {
        const url = roomId.startsWith("http")
            ? roomId
            : `${BASE_URL}${roomId}`

        const html = await request(url)
        const match = html.match(
            /([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/
        )

        if (!match) {
            throw new Error("未找到视频UUID")
        }

        const uuid = match[1]

        return {
            urls: [
                {
                    quality: "Auto",
                    url: `https://surrit.com/${uuid}/playlist.m3u8`
                }
            ]
        }
    }
}