const BASE_URL = "https://missav.live"

async function request(url) {
    const res = await fetch(url, {
        headers: {
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "referer": BASE_URL
        }
    })
    return await res.text()
}

globalThis.plugin = {
    // 基础搜索功能
    async search(keyword) {
        const html = await request(
            `${BASE_URL}/search/${encodeURIComponent(keyword)}`
        )

        const reg = /href="([^"]+)"[^>]*>\s*<img[^>]*src="([^"]+)"[^>]*alt="([^"]+)"/g
        const list = []

        for (const item of html.matchAll(reg)) {
            list.push({
                roomId: item[1],
                title: item[3],
                cover: item[2]
            })
        }
        return list
    },

    // 播放解析
    async getPlayback(roomId) {
        const url = roomId.startsWith("http")
            ? roomId
            : `${BASE_URL}${roomId}`

        const html = await request(url)
        const match = html.match(
          /([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/
        )

        if (!match) {
            throw new Error("未找到视频UUID")
        }

        const uuid = match[1]

        return {
            urls: [
                {
                    quality: "Auto",
                    url: `https://surrit.com/${uuid}/playlist.m3u8`
                }
            ]
        }
    },

    // 垫底的分类回调：防止点进去报“分类错误”
    async category() {
        return [
            { id: "default", name: "全部视频" }
        ]
    },

    // 垫底的渠道/列表回调：防止进入分类后加载失败
    async channel(categoryId, page) {
        // 如果想让主页有数据，可以在这里请求 BASE_URL 的首页并用正则解析后返回
        // 现阶段先返回空数组，引导用户直接使用搜索功能
        return []
    }
}