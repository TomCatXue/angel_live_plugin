const BASE_URL = "https://missav.live"

async function request(url) {

    const res = await fetch(url, {
        headers: {
            "user-agent": "Mozilla/5.0",
            "referer": BASE_URL
        }
    })

    return await res.text()
}

globalThis.LiveParsePlugin = {

    async search(keyword) {

        const html = await request(
            `${BASE_URL}/search/${encodeURIComponent(keyword)}`
        )

        const reg =
          /href="([^"]+)"[^>]*>\s*<img[^>]*src="([^"]+)"[^>]*alt="([^"]+)"/g

        const list = []

        for (const item of html.matchAll(reg)) {

            list.push({
                roomId: item[1],
                title: item[3],
                cover: item[2]
            })
        }

        return list
    },

    async getPlayback(roomId) {

        const url = roomId.startsWith("http")
            ? roomId
            : `${BASE_URL}${roomId}`

        const html = await request(url)

        const uuids = html.match(
          /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/g
        )

        if (!uuids || !uuids.length) {
            throw new Error("未找到视频UUID")
        }

        const uuid = uuids[0]

        return {
            urls: [
                {
                    quality: "Auto",
                    url:
                      `https://surrit.com/${uuid}/playlist.m3u8`
                }
            ]
        }
    }
}
